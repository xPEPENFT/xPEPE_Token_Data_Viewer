﻿Public Class FirstRun

    Dim FirstRun As Boolean
    Dim SQLUsername As String

    Private Sub FirstRun_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        FirstRun = True

        If My.Settings.SQLDB > "" Then
            FirstRun = False
        Else
            FirstRun = True
        End If

        If My.Settings.SQLIP > "" Then
            FirstRun = False
        Else
            FirstRun = True
        End If

        If My.Settings.SQLPassword > "" Then
            FirstRun = False
        Else
            FirstRun = True
        End If

        If My.Settings.SQLUsername > "" Then
            FirstRun = False
        Else
            FirstRun = True
        End If

        If FirstRun = False Then
            Dim Form As New Form1
            Form.Show()
            Me.Close()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim StopRun As Boolean
        StopRun = False

        If ipBox.Text = "" Or portBox.Text = "" Or usernameBox.Text = "" Or passwordBox.Text = "" Or databaseBox.Text = "" Then
            StopRun = True
        End If

        If StopRun = True Then
            MessageBox.Show("Please make sure you fill out all the boxes!")
        End If

        If StopRun = False Then
            My.Settings.SQLDB = databaseBox.Text
            My.Settings.Save()
            My.Settings.SQLPort = portBox.Text
            My.Settings.Save()
            My.Settings.SQLIP = ipBox.Text
            My.Settings.Save()
            My.Settings.SQLPassword = passwordBox.Text
            My.Settings.Save()
            My.Settings.SQLUsername = usernameBox.Text
            My.Settings.Save()
            Dim Form As New Form1
            Form.Show()
            Me.Hide()
        End If
    End Sub
End Class