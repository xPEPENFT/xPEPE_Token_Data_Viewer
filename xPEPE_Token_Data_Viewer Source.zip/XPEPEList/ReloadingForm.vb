﻿Public Class ReloadingForm
    Private Sub ReloadingForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Form As New Form
        Form.Show()
        Me.Close()
    End Sub
End Class