﻿
Imports System.Data
Imports System.Configuration
Imports MySql.Data.MySqlClient
Public Class LoginForm
    Private Sub loginButton_Click(sender As Object, e As EventArgs) Handles loginButton.Click
        Dim getPassword = userIDBox.Text
        Dim Statement As String

        Statement = "SELECT Password, Username FROM Users WHERE Password = @Pass"
        Using con As New MySqlConnection(DBConnection)
            Using cmd As New MySqlCommand(Statement)
                Using sda As New MySqlDataAdapter()
                    cmd.Connection = con

                    cmd.Connection = con
                    cmd.Parameters.AddWithValue("@Pass", getPassword)
                    sda.SelectCommand = cmd

                    Dim ds As New DataSet()
                    sda.Fill(ds)
                    If ds.Tables(0).Rows.Count > 0 Then

                        Form1.Show()
                            Me.Hide()

                        Else
                            MessageBox.Show("Error. Wrong password.", "Login Error...", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    End If
                End Using
            End Using
        End Using
    End Sub

    Private Sub LoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class