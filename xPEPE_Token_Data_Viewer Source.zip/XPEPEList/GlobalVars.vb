﻿Module GlobalVars

    Public DBConnection =
    ("server=" & My.Settings.SQLIP & ";port=" & My.Settings.SQLPort & ";uid=" & My.Settings.SQLUsername & ";pwd=" & My.Settings.SQLPassword & ";database=" & My.Settings.SQLDB)

End Module
