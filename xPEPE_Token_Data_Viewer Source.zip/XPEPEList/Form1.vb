﻿Option Explicit On

Imports System.Data
Imports System.Configuration
Imports MySql.Data.MySqlClient
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Text

Public Class Form1

    Dim tableName As String
    Dim Statement As String
    Dim DBTable As New DataTable
    Dim DBTableSells As New DataTable
    Dim DBTableBuys As New DataTable
    Dim FilterBy As String
    Dim FilterBySells As String
    Dim FilterByBuys As String
    Dim FormLoaded As Boolean







    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        FormLoaded = False

        FilterBy = "Wallet"

        Dim DBBindSource As New BindingSource

        Statement = "SELECT Wallet, Balance FROM richlist"
        Using con As New MySqlConnection(DBConnection)
            Using cmd As New MySqlCommand(Statement)
                Using sda As New MySqlDataAdapter()
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    sda.Fill(DBTable)

                    DBBindSource.DataSource = DBTable
                    DataGridView1.DataSource = DBBindSource
                    sda.Update(DBTable)


                End Using
            End Using
        End Using

        filterBox.Select()
        FormLoaded = True

        Dim DG_cnt As Integer
        DG_cnt = DataGridView1.RowCount
        countBox.Text = DG_cnt

        FilterBySells = "Wallet"

        Dim DBBindSourceSells As New BindingSource

        Statement = "SELECT Seller, xPEPE, XRP, Holdings FROM offersSell"
        Using con As New MySqlConnection(DBConnection)
            Using cmd As New MySqlCommand(Statement)
                Using sda As New MySqlDataAdapter()
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    sda.Fill(DBTableSells)

                    DBBindSourceSells.DataSource = DBTableSells
                    DataGridView2.DataSource = DBBindSourceSells
                    sda.Update(DBTableSells)


                End Using
            End Using
        End Using

        filterBox.Select()
        FormLoaded = True

        Dim DG_cntB As Integer
        DG_cntB = DataGridView2.RowCount
        countBoxSells.Text = DG_cntB

        FilterByBuys = "Wallet"

        Dim DBBindSourceBuys As New BindingSource

        Statement = "SELECT Buyer, xPEPE, XRP, Holdings FROM offersBuy"
        Using con As New MySqlConnection(DBConnection)
            Using cmd As New MySqlCommand(Statement)
                Using sda As New MySqlDataAdapter()
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    sda.Fill(DBTableBuys)

                    DBBindSourceBuys.DataSource = DBTableBuys
                    DataGridView3.DataSource = DBBindSourceBuys
                    sda.Update(DBTableBuys)


                End Using
            End Using
        End Using

        filterBox.Select()
        FormLoaded = True

        Dim DG_cntC As Integer
        DG_cntC = DataGridView3.RowCount
        countBoxBuys.Text = DG_cntC


        Statement = "SELECT Time FROM lastupdate"
        Using con As New MySqlConnection(DBConnection)
            Using cmd As New MySqlCommand(Statement)
                Using sda As New MySqlDataAdapter()

                    cmd.Connection = con
                    sda.SelectCommand = cmd

                    Dim ds As New DataSet()
                    sda.Fill(ds)
                    If ds.Tables(0).Rows.Count > 0 Then
                        offerBoxTimeStamp.Text = ds.Tables(0).Rows(0).Item(0).ToString
                        walletTimeStamp.Text = ds.Tables(0).Rows(0).Item(0).ToString
                    End If

                End Using
            End Using
        End Using

    End Sub

    Private Sub filterBox_TextChanged(sender As Object, e As EventArgs) Handles filterBox.TextChanged
        Dim FilterString As New DataView(DBTable)

        If FilterBy = "Wallet" Then
            FilterString.RowFilter = String.Format("Wallet like '%{0}%'", filterBox.Text)
            DataGridView1.DataSource = FilterString
            Dim DG_cnt As Integer
            DG_cnt = DataGridView1.RowCount
            countBox.Text = DG_cnt
        End If

        If FilterBy = "BalanceEoG" Then
            If filterBox.Text > "" Then
                FilterString.RowFilter = String.Format("Balance >= {0}", filterBox.Text)
                DataGridView1.DataSource = FilterString
                Dim DG_cnt As Integer
                DG_cnt = DataGridView1.RowCount
                countBox.Text = DG_cnt
            End If

        End If

        If FilterBy = "BalanceEoL" Then
            If filterBox.Text > "" Then
                FilterString.RowFilter = String.Format("Balance <= {0}", filterBox.Text)
                DataGridView1.DataSource = FilterString
                Dim DG_cnt As Integer
                DG_cnt = DataGridView1.RowCount
                countBox.Text = DG_cnt
            End If

        End If

        If FilterBy = "BalanceE" Then
            If filterBox.Text > "" Then
                FilterString.RowFilter = String.Format("Balance = {0}", filterBox.Text)
                DataGridView1.DataSource = FilterString
                Dim DG_cnt As Integer
                DG_cnt = DataGridView1.RowCount
                countBox.Text = DG_cnt
            End If

        End If


    End Sub

    Private Sub serialRadio_CheckedChanged(sender As Object, e As EventArgs) Handles serialRadio.CheckedChanged
        FilterBy = "BalanceEoG"
    End Sub

    Private Sub statusRadio_CheckedChanged(sender As Object, e As EventArgs) Handles statusRadio.CheckedChanged
        FilterBy = "Wallet"
    End Sub

    Private Sub EqualOrGreaterToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EqualOrGreaterToolStripMenuItem.Click
        FilterBy = "BalanceEoG"

    End Sub

    Private Sub EqualOrLessToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EqualOrLessToolStripMenuItem.Click
        FilterBy = "BalanceEoL"
    End Sub

    Private Sub EqualToToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EqualToToolStripMenuItem.Click
        FilterBy = "BalanceE"
    End Sub

    Private Sub RefreshDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshDataToolStripMenuItem.Click
        Dim Form As New Form1
        Form.Show()
        Me.Close()
    End Sub




    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        Dim FilterStringB As New DataView(DBTableSells)

        If FilterBySells = "Wallet" Then
            FilterStringB.RowFilter = String.Format("Seller like '%{0}%'", TextBox2.Text)
            DataGridView2.DataSource = FilterStringB
            Dim DG_cntB As Integer
            DG_cntB = DataGridView2.RowCount
            countBoxSells.Text = DG_cntB
        End If
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged
        Dim FilterStringC As New DataView(DBTableBuys)

        If FilterByBuys = "Wallet" Then
            FilterStringC.RowFilter = String.Format("Buyer like '%{0}%'", TextBox3.Text)
            DataGridView3.DataSource = FilterStringC
            Dim DG_cntC As Integer
            DG_cntC = DataGridView3.RowCount
            countBoxBuys.Text = DG_cntC
        End If
    End Sub


    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub
End Class
